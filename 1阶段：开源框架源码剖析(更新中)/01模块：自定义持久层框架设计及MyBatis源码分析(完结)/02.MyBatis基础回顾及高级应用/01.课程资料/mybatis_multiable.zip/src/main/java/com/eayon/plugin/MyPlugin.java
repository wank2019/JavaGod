package com.eayon.plugin;

import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.plugin.*;

import java.sql.Connection;
import java.util.Properties;

/**
 * 自定义插件
 */
@Intercepts({//注意看这个大花括号，也就这说这里可以定义多个@Signature对多个组件对象拦截，都用这个拦截器
        @Signature(type = StatementHandler.class,//你需要拦截MyBatis四大组件中的哪一个
                method = "prepare",//拦截该组件对象中的哪个方法
                args = {Connection.class, Integer.class}//有可能该组件对象中你想拦截的方法有重载，所以再通过参数进行精准定位
        )
})
public class MyPlugin implements Interceptor {

    /**
     * 该方法第三个执行
     * 拦截方法 只要被拦截的目标对象的目标方法被执行时 每次都会执行当前这个方法
     */
    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        //大家可以在目标方法执行时进行一些分页 监控等操作进行增强

        //模拟增强
        System.out.println("对方法进行了增强");

        return invocation.proceed();//执行目标方法
    }

    /**
     * 该方法第二个执行
     * 主要为了把当前的拦截器生成代理对象存到拦截器链中（InterceptorChain类中的List<Interceptor> interceptors = new ArrayList<Interceptor>() 这个集合）
     */
    @Override
    public Object plugin(Object target) {
        //target：被拦截的目标对象
        Object wrap = Plugin.wrap(target, this);//生成代理对象
        return wrap;
    }

    /**
     * 该方法第一个执行
     * 获取配置文件中的参数
     * 该配置文件指核心配置文件sqlMapConfig.xml中<plugins>标签引入本插件时设置的参数
     */
    @Override
    public void setProperties(Properties properties) {
        //获取到的配置文件中的参数
        System.out.println("获取到的配置文件中的参数" + properties);
    }
}
