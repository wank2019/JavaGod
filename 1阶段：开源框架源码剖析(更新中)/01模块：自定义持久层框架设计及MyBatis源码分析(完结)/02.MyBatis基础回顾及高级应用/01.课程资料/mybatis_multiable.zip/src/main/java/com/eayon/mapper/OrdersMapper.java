package com.eayon.mapper;

import com.eayon.pojo.Orders;

import java.util.List;

public interface OrdersMapper {
    //查询订单的同时并查询该订单所属用户信息
    List<Orders> findOrderAndUser();
}
