package com.eayon.test;

import com.eayon.mapper.UserMapper;
import com.eayon.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

public class CacheTest {

    /**
     * 测试一级缓存
     */
    @Test
    public void firstLevelCache() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession(true);//自动提交事务
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        //第一次查询：测试结果第一次查询打印了sql语句，并将查询出来的结果放进了缓存
        User user = userMapper.findUserById(1);
        System.out.println(user);

        //第二次查询：由于使用的使用一个sqlSession，所以他并没有走数据库，没有打印sql，走的是一级缓存
        User user2 = userMapper.findUserById(1);
        System.out.println(user2);

        //判断他俩是否为同一个对象：结果为true
        System.out.println(user == user2);
    }

    /**
     * 测试一级缓存2
     */
    @Test
    public void firstLevelCache2() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession(true);//自动提交事务
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        //第一次查询：测试结果第一次查询打印了sql语句，并将查询出来的结果放进了缓存
        User user = userMapper.findUserById(1);
        System.out.println(user);

        //对查询的数据进行更新：打印了更新语句，并且将缓存中的数据进行了删除
        userMapper.updateUser(new User(1,"李四"));

        //第二次查询：答应了sql语句。在缓存中没有找到该数据，所以走了数据库，并将查询结果房近缓存
        User user2 = userMapper.findUserById(1);
        System.out.println(user2);

        //判断他俩是否为同一个对象：结果为true
        System.out.println(user == user2);
    }


    /**
     * 测试二级缓存
     */
    @Test
    public void secondLevelCache() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);

        //构建三个session
        SqlSession sqlSession1 = sqlSessionFactory.openSession(true);
        SqlSession sqlSession2 = sqlSessionFactory.openSession(true);

        //通过三个不同的session获取三个UserMapper对象
        UserMapper mapper1 = sqlSession1.getMapper(UserMapper.class);
        UserMapper mapper2 = sqlSession2.getMapper(UserMapper.class);

        //使用不同的session（跨session）去进行查询
        User user1 = mapper1.findById(1);//注意这里使用的是Mapper映射文件查询，而非注解
        sqlSession1.close();//清空一级缓存
        User user2 = mapper2.findById(1);

        //判断跨session查询的user是否为同一个  结果：false
        //一级缓存是将查询出来的对象进行缓存，而二级缓存并没有缓存整个对象
        //而是将对象中的数据进行缓存，为我们重新创建了一个新的对象并且将缓存中的数据进行重新赋值
        System.out.println(user1 == user2);

    }


    /**
     * 测试Redis实现二级缓存
     */
    @Test
    public void redisCache() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);

        //构建三个session
        SqlSession sqlSession1 = sqlSessionFactory.openSession(true);
        SqlSession sqlSession2 = sqlSessionFactory.openSession(true);

        //通过三个不同的session获取三个UserMapper对象
        UserMapper mapper1 = sqlSession1.getMapper(UserMapper.class);
        UserMapper mapper2 = sqlSession2.getMapper(UserMapper.class);

        //使用不同的session（跨session）去进行查询
        User user1 = mapper1.findById(1);//注意这里使用的是Mapper映射文件查询，而非注解
        sqlSession1.close();//清空一级缓存
        User user2 = mapper2.findById(1);

        //判断跨session查询的user是否为同一个  结果：false
        //一级缓存是将查询出来的对象进行缓存，而二级缓存并没有缓存整个对象
        //而是将对象中的数据进行缓存，为我们重新创建了一个新的对象并且将缓存中的数据进行重新赋值
        System.out.println(user1 == user2);

    }
}
