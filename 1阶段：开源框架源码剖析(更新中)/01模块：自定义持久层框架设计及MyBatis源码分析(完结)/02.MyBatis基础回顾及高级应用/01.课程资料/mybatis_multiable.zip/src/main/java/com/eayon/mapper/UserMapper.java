package com.eayon.mapper;


import com.eayon.pojo.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface UserMapper {

    //查询所有用户信息，并查出每个用户关联的订单信息
    List<User> findAll();

    //查询用户的同时查询处该用户的所有角色
    List<User> findAllUserAndRole();

    //注解方式：添加用户
    @Insert("insert into user values(#{id},#{username})")
    void addUser(User user);

    //注解方式：修改用户
    @Update("update user set username = #{username} where id = #{id}")
    void updateUser(User user);

    //注解方式：查询用户
    @Select("select * from user")
    List<User> findUsers();

    //注解方式：删除用户
    @Delete("delete from user where id = #{id}")
    void delUser(Integer id);

    //测试一级缓存 及二级缓存
    @Options(useCache = false)//禁用二级缓存 默认开启true
    @Select("select * from user where id = #{id}")
    User findUserById(Integer id);

    //测试二级缓存
    User findById(Integer id);

}
