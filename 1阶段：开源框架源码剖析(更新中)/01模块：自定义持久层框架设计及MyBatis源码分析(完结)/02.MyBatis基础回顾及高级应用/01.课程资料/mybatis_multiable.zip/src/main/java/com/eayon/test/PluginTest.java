package com.eayon.test;

import com.eayon.mapper.UserMapper;
import com.eayon.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author zhengtai.li
 * @ClassName PluginTest
 * @Description //TODO
 * @Copyright 2021 © kuwo.cn
 * @date 2021/3/13 16:40
 * @Version: 1.0
 */
public class PluginTest {

    @Test
    public void test1() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);
        SqlSession sqlSession1 = sqlSessionFactory.openSession(true);
        UserMapper mapper = sqlSession1.getMapper(UserMapper.class);
        User user = mapper.findById(1);
        System.out.println(user);
    }
}
