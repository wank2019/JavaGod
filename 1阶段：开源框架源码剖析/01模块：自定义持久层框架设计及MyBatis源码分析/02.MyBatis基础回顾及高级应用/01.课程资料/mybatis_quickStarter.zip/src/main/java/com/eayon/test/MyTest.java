package com.eayon.test;

import com.eayon.dao.UserDao;
import com.eayon.dao.UserDaoImpl;
import com.eayon.mapper.UserMapper;
import com.eayon.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 测试类
 */
public class MyTest {

    /**
     * 快速开始
     * @throws IOException
     */
    @Test
    public void test1() throws IOException {
        // 读取mybatis的核心配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 通过SqlSessionFactoryBuilder创建一个SqlSessionFactory对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(is);
        // 创建一个sqlSession对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            //第一个参数：statementId，用来定位你要执行UserMapper.xml中的哪个SQL语句（spacename+id）
            //第二个参数：是你要执行sql的对应参数（可不传）
            User user = sqlSession.selectOne("userMapper.findAll");
            System.out.println(user);
        } finally {
            sqlSession.close();
        }
    }


    /**
     * 测试Dao层实现的传统开发方式
     */
    @Test
    public void testTraditionDao() throws IOException {
        UserDao userDao = new UserDaoImpl();
        List<User> all = userDao.findAll();
        System.out.println(all);
    }


    /**
     * 测试代理开发方式
     */
    @Test
    public void testProxyDao() throws IOException {
        // 读取mybatis的核心配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 通过SqlSessionFactoryBuilder创建一个SqlSessionFactory对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(is);
        // 创建一个sqlSession对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            //获得MyBatis框架生成的UserMapper接口的代理对象
            UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
            User user = userMapper.findById(1);
            System.out.println(user);
        } finally {
            sqlSession.close();
        }
    }


    /**
     * 测试动态SQL语句-- if - where
     * @throws IOException
     */
    @Test
    public void test2() throws IOException {
        // 读取mybatis的核心配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 通过SqlSessionFactoryBuilder创建一个SqlSessionFactory对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(is);
        // 创建一个sqlSession对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            //获得MyBatis框架生成的UserMapper接口的代理对象
            UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
            User user = new User();
            user.setId(1);
            List<User> users = userMapper.findByCondition(user);
            System.out.println(users);
        } finally {
            sqlSession.close();
        }
    }

    /**
     * 测试动态SQL语句-- foreach
     * @throws IOException
     */
    @Test
    public void test3() throws IOException {
        // 读取mybatis的核心配置文件
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 通过SqlSessionFactoryBuilder创建一个SqlSessionFactory对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(is);
        // 创建一个sqlSession对象
        SqlSession sqlSession = sqlSessionFactory.openSession();
        try {
            //获得MyBatis框架生成的UserMapper接口的代理对象
            UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
            List<Integer> ids = new ArrayList();
            ids.add(1);
            ids.add(2);
            List<User> users = userMapper.findByIds(ids);
            System.out.println(users);
        } finally {
            sqlSession.close();
        }
    }
}
