package com.eayon.mapper;

import com.eayon.pojo.User;

import java.util.List;

public interface UserMapper {

    User findById(Integer id);

    //多条件查询：演示if
    public List<User> findByCondition(User user);

    //多值查询：演示foreach
    public List<User> findByIds(List<Integer> ids);
}
