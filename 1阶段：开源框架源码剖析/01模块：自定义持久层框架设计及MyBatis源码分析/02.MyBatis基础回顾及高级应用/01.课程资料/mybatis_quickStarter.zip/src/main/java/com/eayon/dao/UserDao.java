package com.eayon.dao;


import com.eayon.pojo.User;

import java.io.IOException;
import java.util.List;

public interface UserDao {

    List<User> findAll() throws IOException;

}
