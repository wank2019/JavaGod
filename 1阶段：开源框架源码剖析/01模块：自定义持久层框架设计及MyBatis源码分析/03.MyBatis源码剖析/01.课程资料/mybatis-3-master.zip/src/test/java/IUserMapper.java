import java.util.List;

public interface IUserMapper {

    public List<Object> findAllUser();

}
